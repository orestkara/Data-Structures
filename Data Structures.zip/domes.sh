#!/bin/bash

gcc domes.h
gcc domes.c main.c -lm -o new
./new     

