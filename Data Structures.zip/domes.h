#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include<time.h>
struct junction{
        int num;        
        double x;
        double y;
};

struct node{
	struct junction *e;
	struct node *next;
}  ; 

//********************
double randomplace(int lim);
struct junction * createJunction(int e,double x,double y);
void createaddnode(struct node **l, struct junction *j);
int findNode(int n, struct node *l);
void deleteList(struct node * l );
int GetArrayLength(char *filename);
double distance(int ax,int ay,int bx , int by);
double calculateA(double k ,double dist);
double calculateR(double k ,double dist);
double min(double a, double b);
double max(double a , double b);
double Temp( int i,int n);

