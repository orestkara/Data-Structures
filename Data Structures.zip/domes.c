#include "domes.h"
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

//********************
double randomplace(int lim){
        
        double sun= rand() %(lim+1);
        //rand()%(maxnnumber +1 -minnumber) + minnumber
        return sun;
}

//***********************************
struct junction * createJunction(int e,double x,double y){
        struct junction* n =(struct junction*)malloc(sizeof(struct junction));
	if(n==NULL){
        printf("Unable to allocate memory for new node");
		return NULL;//goes here if there is  a problem while allocating the memory
    
	}
        n->num=e;
        if(x==0 && y==0){
            n->x=randomplace(1280);
            n->y=randomplace(720);
        }else{
            n->x=x;
            n->y=y;
        }

        return n;
}
//********************************************
void createaddnode(struct node **l, struct junction *j){
        struct node * n = (struct node*)malloc(sizeof( struct node));

        if(n== NULL){
        printf("Unable to allocate memory for new node\n");
        //goes here if there is  a problem while allocating the memory
            }
        struct node *last=*l;
        n->e=j;
        n->next=NULL;


        if(*l == NULL){
            *l = n;
          
        }
        else{
        //else loop through the list and find the last
        
            while(last->next!=NULL){//finds the end of the list to add the node there
		        last=last->next;

	            }
            last->next=n;
        }
    
}
//***********************
int findNode(int n, struct node *l){
	if(l==NULL){
		return 0;//goes here if the list is empty
	}
	
	struct node *tmp=l;
	while(tmp->e->num!=n){
		tmp=tmp->next;
		if(tmp==NULL){
			return 0;
		}


	}
	return n;	
}
//*********************************
//deletes the list at the end of the program so that we free the memory we hhave allocated
void deleteList(struct node * l ){
	if(l==NULL){//goes here if the list is empty
        
		return ;
	}
	struct node*tmp=l;
	
	while(tmp!=NULL){//deletes the nodes one by one
		l=tmp->next;
		free(tmp);
		tmp=l;
	}
	free(l);//frees allocated memory from createList()
}
//******************************
//******************************
int GetArrayLength(char *filename){
    int length=0;
    char line[20];
    
    FILE*f=fopen(filename,"r");
	if(f==NULL){//goes here if there is no file on the folder
		printf("\n\nThere is no file with that name to take data from.\nPlease provide the correct name\n");
        return 1;
        }
        else{//gets the pointer to the start of the file
		    fseek(f,0,SEEK_SET);
		    while(fgets(line,sizeof(line),f)!=NULL){//takes line one by one
                   
			    if(line[0]=='p'){//dimacs files for graphs set the edges and nodes numbers on lines with 'p'
                    sscanf(line,"%*[^0123456789]%d",&length);

                 }
            }
        }
    fclose(f);

    return length;

}

//**********************************

    
double distance(int ax,int ay,int bx , int by){
        double dist;
        dist=sqrt((pow(ax-bx,2))+(pow(ay-by,2)));
        return dist;
}

//*************************
double calculateA(double k ,double dist){

        double  attr=(pow(dist,2))/k;

        return attr;
}

double calculateR(double k ,double dist){
        
        double rep=-(pow(k,2)/dist);
        return rep;
}
double min(double a, double b){
    double min;
    if(a>b){
        min=b;    
    }else{
        min=a;
    }
    return min;
}
double max(double a , double b){
    double max;
    if(a>b){
        max=a;
    }else{
        max=b;
    }

    return max;
}
//*********************
//**********************
double Temp( int i,int n){
	int a=min(720,1280);
	double temp=(a/10)-((a/(10*n))*i);
    return temp;

}

//*********************
