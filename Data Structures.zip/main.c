#include "domes.h"

//*********************
int main(){
	FILE*out=fopen("new.dot","w");

    srand(time (NULL));
    int i ;
    int h =720; //h=720;
    int w=1280;//w=1280;
    int n ;//number of nodes taken from input;
    char filename[20];
    printf("Please provide the name of the file with the Graph's data\n");
    printf("INPUT:\n");
    scanf("%s",&*filename);
    
    fprintf(out,"graph G {\n");
    fprintf(out,"\tgraph [bb=\"0,0,1280,720\"];\n");
    fprintf(out,"\tnode [label=\"\\N\"];\n");

   
    n=GetArrayLength(filename);
    if(n==1){
        return 1;
    }
    struct node * Array[n-1];
    for(i=0;i<=n-1;i++){
      Array[i]=NULL;

    }//initialization twn lists
    
    for(i=0;i<=n-1;i++){
       
        struct junction * j=createJunction(i+1,0,0);
        
        createaddnode(&Array[i],j);
  
    }//In every array[i] there's  the head of every list
    double k = 0.5 * sqrt((w*h)/n);

    double dist, frep ,fattr , temp , xdisp , ydisp , xpos, ypos , posx , posy;
    int a ,b;
    char *ptr;
    
    char line[20];
    FILE*f=fopen(filename,"r");
    if(f==NULL){//goes here if there is no file on the folder
		printf("\n\nThere wa a problem with reading the file\n");
       }else{//gets the pointer to the start of the file
		    fseek(f,0,SEEK_SET);
		    while(fgets(line,sizeof(line),f)!=NULL){//takes line one by one

			    if(line[0]=='e'){//an einai grammh pou periexei info gia edge

                    if(2 == sscanf(line,"%*[^0123456789]%d%*[^0123456789]%d",&a,&b)){

                      double x1,x2,y1,y2;
                      x1=Array[2]->e->x;

                      y1=Array[b-1]->e->y;

                      x2=Array[a-1]->e->x;

                      y2=Array[a-1]->e->y;
        
                      struct junction * j1=createJunction(b,x1,y1); 
                      createaddnode(&Array[a-1],j1);
                      struct junction * j2=createJunction(a,x2,y2);
                      createaddnode(&Array[b-1],j2);
                      
                     }
                }
                    
             }
         }
    fclose(f);
 //every list is filled with needed nodes


    for(i=0;i<=n-1;i++){

            xdisp=0;
            ydisp=0;
            struct node *tmp=Array[i]->next;
            while(tmp != NULL){
                xpos=Array[i]->e->x;
                ypos=Array[i]->e->y;
                posx=tmp->e->x;
                posy=tmp->e->y;
               
                dist=distance(xpos,ypos,posx,posy);

                fattr=calculateA(k,dist);

                frep=calculateR(k,dist);

                double fol=abs(fattr+frep);

                xdisp=xdisp + ((xpos/sqrt((pow(xpos,2)) +(pow(ypos,2))))*fol);
                ydisp=ydisp + ((ypos/sqrt((pow(xpos,2))+(pow(ypos,2))))*fol);
                
                tmp=tmp->next;
                }
                int l;
                int found=0;
               for(l=1;l<=n;l++){
                    found=findNode(l,Array[i]);
                    if(found==0){
                        posx=Array[l-1]->e->x;
                        posy=Array[l-1]->e->y;
                        dist=distance(xpos,ypos,posx,posy);
                        frep=calculateR(k,dist);
                        xdisp=xdisp + (xpos/sqrt(pow(xpos,2) +pow(ypos,2)))*frep;
                        ydisp=ydisp + (ypos/sqrt(pow(xpos,2)+pow(ypos,2)))*frep;
                    }
                
               }
            
            temp=Temp(i,n);
           
            xdisp=max(min(xdisp,temp),-temp);
            ydisp=max(min(ydisp,temp),-temp);
            
            xpos=xpos+xdisp;
            ypos=ypos+ydisp;

            xpos=min(w,max(0,xpos));
            ypos=min(h,max(0,ypos));
            
            Array[i]->e->x=xpos;
            Array[i]->e->y=ypos;


        }
    for(i=0;i<=n-1;i++){
         fprintf(out,"\t%d [height=1,width=1,pos=\"%f,%f!\"]\n",(i+1) ,Array[i]->e->x ,Array[i]->e->y);
      }
    for(i=0;i<=n-1;i++){
        deleteList(Array[i]);
    }//free al alocated memory used for this programin the form of nodes and junctions

    FILE*fi=fopen(filename,"r");
    if(f==NULL){//goes here if there is no file on the folder
		printf("\n\nThere wa a problem with reading the file\n");
       }else{//gets the pointer to the start of the file
		    fseek(f,0,SEEK_SET);
		    while(fgets(line,sizeof(line),f)!=NULL){//takes line one by one

			    if(line[0]=='e'){//an einai grammh pou periexei info gia edge

                    if(2 == sscanf(line,"%*[^0123456789]%d%*[^0123456789]%d",&a,&b)){


                      fprintf(out,"\t%d -- ",a);
                      fprintf(out,"%d;\n",b);
                      }
                }
                    
             }
         }
    fclose(fi);

    fprintf(out,"}\n");
    fclose(out);
    return 0 ;
}
