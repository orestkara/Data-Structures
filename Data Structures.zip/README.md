# instructions for the execution of the program
 **the files are:**
      main.c
      
      domes.sh
      
      domes.h
      domes.c
      *every file that is created or is running can be compiled by the program*
      the executable file runs only after command ./domes.sh
      **the input file must be in the same directory with above files in order to be executed (for example if the file with the graph info is "domes.txt" this file should be moved in the same directory as the program files)**
      **if permission is denied you can run the command chmod 755 domes.sh**
      
      
<!--stackedit_data:
eyJoaXN0b3J5IjpbLTE1NDI5NzQ1NDUsLTIwMDU3MzE3MTAsMT
EzODQ0MDgwOCwxNDU5NzcxMDAxLDE5OTYwNjM3MzUsLTE3MDI2
NzM0MjMsLTk0NzA4MDg5N119
-->